package warnet;

public class warnetgui {
	String nama;
	String password;
	String jam;
	String harga;
	
	
	
	@Override
	public String toString() {
		return "warnet [nama=" + nama + ", password=" + password + ", jam=" + jam + ", harga=" + harga + "]";
	}
	
	public warnetgui(String nama, String password, String jam, String harga) {
		super();
		this.nama = nama;
		this.password = password;
		this.jam = jam;
		this.harga = harga;
	}
	public String getHarga() {
		return harga;
	}

	public void setHarga(String harga) {
		this.harga = harga;
	}

	public String getNama() {
		return nama;
	}
	public void setNama(String nama) {
		this.nama = nama;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getJam() {
		return jam;
	}
	public void setJam(String jam) {
		this.jam = jam;
	}
	
	
}
