package warnet;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import java.awt.Color;
import javax.swing.JEditorPane;
import javax.swing.JList;
import javax.swing.JPasswordField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JRadioButtonMenuItem;
import com.jgoodies.forms.factories.DefaultComponentFactory;



public class billing {

	private JFrame frame;
	private JTextField nama;
	private JPasswordField pw;
	private JTextField JB;
	int harga;
	ArrayList<warnetgui> warnetsm = new ArrayList<warnetgui>();
		

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					billing window = new billing();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public billing() {
		initialize();
	}
	
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.CYAN);
		frame.setBounds(100, 100, 717, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		nama = new JTextField();
		nama.setBounds(136, 49, 222, 20);
		frame.getContentPane().add(nama);
		nama.setColumns(10); 
		
		JComboBox jam = new JComboBox();
		jam.setBounds(136, 116, 118, 22);
		jam.setModel(new DefaultComboBoxModel(new String[] {"--PILIH JAM---", "1 jam", "5 jam", "10 jam"}));
		frame.getContentPane().add(jam);
		
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(129, 256, 263, 194);
		frame.getContentPane().add(scrollPane);
		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		scrollPane.setViewportView(textArea);
		
		
		pw = new JPasswordField();
		pw.setBounds(136, 82, 222, 20);
		pw.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				char ps = e.getKeyChar();
				if(!(Character.isDigit(ps))) {
					e.consume();
				} 
			}
		});
		pw.setColumns(10);
		frame.getContentPane().add(pw);
		
		JB = new JTextField();
		JB.setBounds(136, 213, 222, 20);
		JB.setColumns(10);
		frame.getContentPane().add(JB);
		
		JButton btnPembayaran = new JButton("Pembayaran");
		btnPembayaran.setBounds(136, 166, 116, 23);
		btnPembayaran.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String nm = nama.getText();
     			String paw = "";
				String jm = jam.getSelectedItem().toString();
				if (jam.getSelectedItem() == "1 jam") {
					harga = 4000;
				}
				else if (jam.getSelectedItem() == "5 jam") {
					harga = 10000;
				}
				else if (jam.getSelectedItem() == "10 jam") {
					harga = 15000;
				}
				
				String h = String.valueOf(harga);
				
 
				warnetgui p = (new warnetgui (nm, paw, jm, h));
				warnetsm.add(p);
				String a ="";
				String b ="";
				
				for (int i = 0; i < warnetsm.size(); i++) {
					 b = (warnetsm.get(i).harga);
					JB.setText(b);
					a = ("Nama \t:" + warnetsm.get(i).nama + "\njam \t:" + warnetsm.get(i).jam
							+ "\njumlah bayar \t:" + warnetsm.get(i).harga+"\n" + "\n");
					
				}
				textArea.append(a);
			}
		});
		frame.getContentPane().add(btnPembayaran);
		
	
		
		JLabel lblNewLabel_4 = new JLabel("       Nama Pengguna");
		lblNewLabel_4.setBounds(0, 47, 116, 19);
		lblNewLabel_4.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_4.setFont(new Font("Yu Gothic UI", Font.BOLD, 12));
		lblNewLabel_4.setForeground(Color.BLACK);
		frame.getContentPane().add(lblNewLabel_4);
		
		
		JLabel lblNewLabel_5 = new JLabel("         Password");
		lblNewLabel_5.setBounds(10, 84, 99, 14);
		lblNewLabel_5.setFont(new Font("Yu Gothic UI", Font.BOLD, 12));
		frame.getContentPane().add(lblNewLabel_5);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setBounds(276, 166, 116, 23);
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				nama.setText(null);
				pw.setText(null);
				jam.setSelectedItem(null);
				textArea.setText(null);
		        JB.setText(null);
			}
		});
		frame.getContentPane().add(btnReset);
		
		JLabel lblNewLabel_5_1 = new JLabel("    Jumlah Bayar");
		lblNewLabel_5_1.setBounds(27, 216, 99, 14);
		frame.getContentPane().add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("                             BILLING WARNET GUI");
		lblNewLabel_4_1.setBounds(160, 11, 263, 19);
		lblNewLabel_4_1.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 12));
		lblNewLabel_4_1.setVerticalAlignment(SwingConstants.TOP);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		JLabel lblNewLabel_5_2 = new JLabel(" Jumlah Jam");
		lblNewLabel_5_2.setBounds(27, 120, 99, 14);
		lblNewLabel_5_2.setToolTipText("");
		lblNewLabel_5_2.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel_5_2.setFont(new Font("Yu Gothic UI", Font.BOLD, 12));
		frame.getContentPane().add(lblNewLabel_5_2);
		
	
		

		
		
		
		
	}
}
